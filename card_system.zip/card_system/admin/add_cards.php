<?php
ob_start();
include('includes/db.php');
session_start();

if (empty($_COOKIE['remember_me'])) {

    if (empty($_SESSION['admin_id'])) {

        header('location:login.php');
    }
}

$response = null;


if (isset($_POST['submit'])) {



    $category_id = $_POST["category"];
    $company_name = $_POST["company_name"];
    $location = $_POST["location"];
    $business_description = $_POST["business_description"];
    $investment_details = $_POST["investment_details"];
    $investment_range = $_POST["investment_range"];
    $property_details = $_POST["property_details"];
    $training_details = $_POST["training_details"];
    $agreement = $_POST["agreement"];
    $listing_owner_email = $_POST["listing_owner_email"];




    $folder = "../images/listing-images/";

    try {
        //code...
        $stmt = $conn->prepare("INSERT INTO `listings`(`category_id` ,`company_name`,`location`,`business_description`,`investment_details`,`investment_range`,`property_details`,`training_details`,`agreement`,`listing_owner_email`,`created_at`) VALUES (:category_id,:company_name,:location,:business_description,:investment_details,:investment_range, :property_details, :training_details, :agreement,:listing_owner_email,CURRENT_TIMESTAMP)");

        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':company_name', $company_name);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':business_description', $business_description);
        $stmt->bindParam(':investment_details', $investment_details);
        $stmt->bindParam(':investment_range', $investment_range);
        $stmt->bindParam(':property_details', $property_details);
        $stmt->bindParam(':training_details', $training_details);
        $stmt->bindParam(':agreement', $agreement);
        $stmt->bindParam(':listing_owner_email', $listing_owner_email);


        $stmt->execute();

        $last_listing_id = $conn->lastInsertId();

        foreach ($_FILES["images"]["tmp_name"] as $key => $tmp_name) {

            if ($_FILES['images']['name'][$key] != "") {
                $image =  time() . $_FILES['images']['name'][$key];
                $path = $folder . $image;
                move_uploaded_file($_FILES['images']['tmp_name'][$key], $path);


                $stmt = $conn->prepare("INSERT INTO `listing_images`( `listing_id`,`image`) VALUES (:listing_id,:image)");

                $stmt->bindParam(':listing_id', $last_listing_id);
                $stmt->bindParam(':image', $image);

                $stmt->execute();
            }
        }

        $response = "success";
    } catch (PDOException $e) {
        //throw $th;

        $response = $e->getMessage();
    }
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once("includes/head.php"); ?>

    <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link type="text/css" rel="stylesheet" href="assets/image-uploader/image-uploader.min.css">
    <title>Add Listing</title>
</head>

<body class="page-body">

    <div class="page-container">
        <!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->

        <!-- leftbar starts -->

        <?php include_once("includes/left-bar.php"); ?>

        <!-- leftbar ends -->

        <div class="main-content">

            <div class="row">

                <!-- header starts-->
                <?php include_once("includes/header.php"); ?>
                <!-- header ends -->

            </div>

            <hr />

            <ol class="breadcrumb bc-3">
                <li>
                    <a href="index.php"><i class="fa-home"></i>Home</a>
                </li>
                <li>

                    <a href="#">Listing</a>
                </li>
                <li class="active">

                    <strong>Add Listing</strong>
                </li>
            </ol>

            <h2>Add Listing</h2>
            <br />


            <div class="row">
                <div class="col-md-12">

                    <div id="notification-div">

                        <?php if (isset($response)) {

                            if ($response == "success") {
                        ?>

                                <div class="alert alert-success alert-dismissible" role="alert">
                                    <strong>Congrats! Successfully Added</strong> <br><br>

                                    <a href="all_listings.php"> All Listings</a>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                            <?php

                            } else {
                            ?>

                                <div class="alert alert-danger alert-dismissible" role="alert">
                                    <strong>OOPs! <?php echo $response; ?></strong> <br><br>

                                    <a href="all_listings.php">All Listings</a>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                        <?php
                            }
                        } ?>

                    </div>

                    <div class="panel panel-primary" data-collapsed="0">

                        <div class="panel-heading">
                            <div class="panel-title">
                                Add Listing Info
                            </div>

                            <div class="panel-options">
                                <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                                <a href="#" data-rel="reload"><i class="entypo-arrows-ccw"></i></a>

                            </div>
                        </div>

                        <div class="panel-body">

                            <form id="form" method="POST" role="form" enctype="multipart/form-data" class="form-horizontal form-groups-bordered">

                                <div class="form-group">
                                    <label class="col-sm-3 control-label">Add Images</label>

                                    <div class="col-sm-8">

                                        <div class="input-field">
                                            <label class="active">Photos</label>
                                            <div class="input-images-1" style="padding-top: .5rem;"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Category</label>

                                    <div class="col-sm-5">
                                        <select name="category" id="" class="form-control">
                                            <?php
                                            $query = $conn->prepare(
                                                "SELECT * from categories"
                                            );
                                            $query->execute();
                                            while ($result = $query->fetch(PDO::FETCH_ASSOC)) {

                                            ?>

                                                <option value="<?php echo $result["id"] ?>"><?php echo ucwords($result["category"]) ?></option>

                                            <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>



                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Company Name</label>

                                    <div class="col-sm-5">
                                        <input required="" type="text" name="company_name" class="form-control" id="field-1" placeholder="Company Name">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Base Location</label>

                                    <div class="col-sm-5">
                                        <input required="" type="text" name="location" class="form-control" id="field-1" placeholder="Base Location">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Business Description</label>

                                    <div class="col-sm-9">
                                        <textarea required placeholder="Business Description" name="business_description" class="form-control ckeditor"></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Investment Details</label>

                                    <div class="col-sm-9">
                                        <input type="text" required class="form-control" placeholder="Investment Details" name="investment_details">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Investment Range</label>

                                    <div class="col-sm-9">
                                        
                                        <select name="investment_range" class="form-control" required>                                      
                                            
                                            <option value="Below 5 Lakhs">Below 5 Lakhs</option>
                                            <option value="5 to 10 Lakhs">5 to 10 Lakhs</option>
                                            <option value="10 to 20 Lakhs">10 to 20 Lakhs</option>
                                            <option value="More than 20 Lakhs">More than 20 Lakhs</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Property Details</label>

                                    <div class="col-sm-9">
                                        <input required type="text" class="form-control" placeholder="Property Details" name="property_details">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Training Details</label>

                                    <div class="col-sm-9">
                                        <textarea required rows="4" placeholder="Training Details" name="training_details" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Agreement & Terms Details</label>

                                    <div class="col-sm-9">
                                        <textarea required rows="4" placeholder="Agreement & Terms Details" name="agreement" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="field-1" class="col-sm-3 control-label">Owner Email</label>

                                    <div class="col-sm-9">
                                        <input required type="email" class="form-control" placeholder="Owner Email" name="listing_owner_email">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-3 col-sm-5">
                                        <button type="submit" name="submit" class="btn btn-default">Add listing</button>
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>

                </div>
            </div>





            <!-- Footer starts -->
            <?php include_once("includes/footer.php"); ?>
            <!-- Footer end -->

        </div>




    </div>




    <!-- Bottom scripts (common) -->
    <script src="assets/js/gsap/TweenMax.min.js"></script>
    <script src="assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/joinable.js"></script>
    <script src="assets/js/resizeable.js"></script>
    <script src="assets/js/neon-api.js"></script>


    <!-- Imported scripts on this page -->
    <script src="assets/js/bootstrap-switch.min.js"></script>
    <script src="assets/js/neon-chat.js"></script>
    <script src="assets/js/ckeditor/ckeditor.js"></script>
    <script src="assets/js/ckeditor/adapters/jquery.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="assets/js/neon-custom.js"></script>


    <!-- Demo Settings -->
    <script src="assets/js/neon-demo.js"></script>

    <script src="assets/js/jquery.validate.min.js"></script>

    <script src="assets/image-uploader/image-uploader.min.js"></script>


    <script>
        $('.input-images-1').imageUploader();
    </script>


</body>

</html>